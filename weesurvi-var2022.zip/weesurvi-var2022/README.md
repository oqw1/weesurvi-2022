create **.***	Create file.
remove **.***	Remove file.
copy **.*** **.***	Copy file.
write **.*** #####	Write file.
read **.***	Read file.
append **.*** #####	Append file.
break say	     Exit the conversation.
len **.***	Count the number of characters.
pi			PI
abs ***		Absolute value