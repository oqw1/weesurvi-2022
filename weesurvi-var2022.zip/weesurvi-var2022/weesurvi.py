import os

with open("weesurvi_set_up.ini") as location:
    aassdd = location.read()
aassdd = aassdd.split()
ssdd = aassdd[1]
def error(ert='***',a='t'):
    if a == 't':
        print("<FileError>:\"" + ert + "\"")
    else:
        print("<CodeError>:\"" + ert + "\"")
    print("What is " + ert + "?")
say = ''
print("Weesurvi.[type:var2022\\Microsoft Windows]")
while True:
    ao = input(ssdd + ">")
    say += ao + "\n"
    aos = ao.split()
    try:
        #create
        if aos[0] == 'create': 
            try:
                with open(aos[1], 'x') as cw:
                    cw.write('')
            except FileExistsError:
                error(ao)

        elif aos[0] == 'copy':
            try:
                #copy
                with open(aos[1], encoding='utf-8') as cow:
                    a = cow.read()
            except FileNotFoundError:
                error(ao)
            finally:
                with open(aos[2], 'w', encoding='utf-8') as coo:
                    coo.write(a)

        elif aos[0] == 'remove':
            try:
                #remove
                os.remove(aos[1])
            except FileNotFoundError:
                error(ao)
        elif aos[0] == 'write':
            #write
            with open(aos[1],'w') as wr:
                wr.write(aos[2])
        elif aos[0] == 'read':
            try:
                #read
                with open(aos[1]) as rea:
                    cpp = rea.read()
                    print("read:\n" + cpp)
            except FileNotFoundError:
                error(ao)
        elif aos[0] == 'break' and aos[1] == 'say':
            #break
            break
        elif aos[0] == 'append':
            try:
                #append
                with open(aos[1],'a') as app:
                    app.write(aos[2])
            except FileNotFoundError:
                error(ao)
        elif aos[0] == 'save':
            #save
            if aos[1] == 'clean':
                with open(aos[2],'w') as sas:
                    sas.write(say)
                say = ''
            elif aos[1] == 'save':
                with open(aos[2],'w') as sas:
                    sas.write(say)
            else:
                error(ao,'f')
        elif aos[0] == "pi":
            #save
            print(3.1415926535897932384626433832795028197169399375105820974944)
        elif aos[0] == "abs":
            #abs
            num = aos[2]
            try:
                int(num)
            except ValueError:
                error(ao,'f')
            finally:
                print(abs(num))
        elif aos[0] == 'strlen':
            try:
                #len
                with open(aos[1]) as rea:
                    cpp = rea.read()
            except FileNotFoundError:
                error(ao)
            finally:
                print(len(cpp))
        else:
            error(ao,'f')
    except IndexError:
        error(ao,'f')